// Haal de nodige HTML elementen op uit de DOM en plaats ze in variabelen

// Hou in een variabele met data type Boolean bij of de lamp aan of uit staat

// Hou in een variabele met data type Number bij hoeveel keer de lichtknop werd ingeduwd.

/**
 * Voeg een eventListener toe aan de switch die checkt wanneer de switch verandert.
 * - Update daarin een klasse op een element
 * - Vermeerder de variabele die het aantal kliks bijhoudt
 * - Geef het aantal kliks weer in het witte kader bovenaan links
 * - Pas de boolean aan die checkt of de lamp aan of uit staat
 */

/**
 * Voeg een eventListener toe aan de switch die checkt wanneer de cursor wordt ingedrukt
 * Pas daarna de gepaste klasse aan op het gepaste element.
 */

/**
 * Voeg een eventListener toe aan de switch die checkt wanneer de cursor niet meer wordt ingedrukt
 * Pas daarna de gepaste klasse aan op het gepaste element.
 */

/**
 * Schrijf een functie die het totaalverbruik berekent en dit toont in het witte kader bovenaan links.
 * De berekening hoeft niet te kloppen; het volstaat om om de seconde het getal te verhogen met 1.
 */

/**
 *  Schrijf een setInterval() functie die om de seconde het totaalverbruik herberekend.
 */

document.addEventListener("DOMContentLoaded", initialize);
function initialize() {
  const bulb = document.querySelector("#bulb");
  const bulbSwitch = document.querySelector("#switch");
  const switchCheckBox = document.querySelector("#checkbox-switch");
  const counter = document.querySelector("#times-switched");
  const totalUsageElement = document.querySelector("#total-usage");
  let isOn = false;
  switchCheckBox.addEventListener("change", function () {
    console.log(isOn);
    if (isOn == true) {
      isOn = false;

      bulb.classList.add("off");
    } else {
      isOn = true;

      bulb.classList.remove("off");
    }
  });
  let count = 0;
  switchCheckBox.addEventListener("click", function () {
    count++;
    counter.innerHTML = count;
    console.log("knop geklikt");
  });
  bulbSwitch.addEventListener("mousedown", function () {
    bulb.classList.add("knipperen");
  });
  bulbSwitch.addEventListener("mouseup", function () {
    bulb.classList.remove("knipperen");
  });
  let totalUsage = 0;
  function UpdateTotalUsage() {
    if (isOn) {
      totalUsage++;
      totalUsageElement.innerHTML = totalUsage;
    }
  }
  setInterval(UpdateTotalUsage, 1000);
}
